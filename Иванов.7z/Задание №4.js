let a = +prompt("Введите число a", 3);
let b = +prompt("Введите число b", 4);
let slozhenie = a + b;
let proizvedenije = a * b;
let srarifm = (a + b) / 2;
alert(`Сумма a и b равна: ${slozhenie}`);
alert(`Произведение a и b равно: ${proizvedenije}`);
alert(`Среднее арифметическое a и b равно: ${srarifm}`);