let n = prompt("n");
alert(`Я буду зарабатывать $${n} в час`);