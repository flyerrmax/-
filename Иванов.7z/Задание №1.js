let message = ('Жить хорошо, а хорошо жить еще лучше');
document.writeln(message)
