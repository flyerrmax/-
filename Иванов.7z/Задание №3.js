var x=10, y=12, z=3;
x = x+y-((x++)*z)
document.writeln(x+y-((x++)*z))

var x=10, y=12, z=3;
z = —x - y * 5
document.writeln(--x - y * 5)

var x=10, y=12, z=3;
y = (y / x) + (5 % z)
document.writeln((y / x) + (5 % z))

var x=10, y=12, z=3;
z = x++ + y * 5
document.writeln(z = x++ + y * 5)

var x=10, y=12, z=3;
x = y - x++ * z
document.writeln(x = y - x++ * z)